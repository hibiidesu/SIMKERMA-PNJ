<p align="center"><a href="https://simkerma.pnj.my.id" target="_blank"><img src="https://github.com/hibiidesu/SIMKERMA-PNJ/blob/main/public/img/header.jpg" width="400"></a></p>

## SIMKERMA - PNJ
SISTEM INFORMASI KERJA SAMA POLITEKNIK NEGERI JAKARTA (PNJ)

[PROD](https://simkerma.pnj.ac.id/)
[DEV](https://simkerma.scz.my.id/)

## TODO LIST
0. Sedikit UI Rework
1. Menambah role (pic, legal)
2. Validasi bertingkat (pic -> legal -> pimpinan)
3. Notifikasi Email (Reminder)
4. Tracking
