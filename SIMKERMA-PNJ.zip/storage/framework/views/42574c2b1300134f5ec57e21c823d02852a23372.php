<?php $__env->startSection('heading', 'User'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/choices.js/choices.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <?php if(session('error')): ?>
                    <div class="alert alert-danger">
                        <p><?php echo e(session('error')); ?></p>
                    </div>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <p><?php echo e(session('success')); ?></p>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>
                <?php if(Request::segment(2) == 'my-profile'): ?>
                    <form class="form form-vertical" method="post" action="<?php echo e(url('/'.Request::segment(1).'/my-profile/update')); ?>">
                <?php else: ?>
                    <form class="form form-vertical" method="post" action="<?php echo e(url('/admin/user/update')); ?>">
                        <input type="hidden" readonly required class="form-control" name="id" value="<?php echo e($data->id); ?>">
                <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="name">Nama <span class="text-danger">*</span></label>
                                    <input type="text" id="name" class="form-control" name="name" required value="<?php echo e($data->name); ?>">
                                </div>
                            </div>
                            <?php if(Request::segment(2) != 'my-profile'): ?>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="username">Username <span class="text-danger">*</span></label>
                                    <input type="text" id="username" class="form-control" name="username" required value="<?php echo e($data->username); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="email">Email <span class="text-danger">*</span></label>
                                    <input type="text" id="email" class="form-control" name="email" required value="<?php echo e($data->email); ?>">
                                </div>
                            </div>

                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="role_id">Role <span class="text-danger">*</span></label>
                                    <select class="form-select" id="role_id" name="role_id" required>
                                        <option value="">-</option>
                                        <?php $__currentLoopData = $role; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>" <?php echo e($data->role_id == $item->id ? 'selected' : ''); ?>><?php echo e($item->role_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <?php endif; ?>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="password">Password</label>
                                    <input type="password" id="password" class="form-control" name="password" >
                                    <small id="emailHelp" class="form-text text-muted">Abaikan jika tidak ingin mengubah password</small>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="re_password">Masukan Ulang Password</label>
                                    <input type="password" id="re_password" class="form-control" name="re_password" >
                                    <small id="emailHelp" class="form-text text-muted">Abaikan jika tidak ingin mengubah password</small>
                                </div>
                            </div>

                            <div class="col-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary mb-1">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('admin/vendors/choices.js/choices.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/pages/form-element-select.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/user/edit.blade.php ENDPATH**/ ?>