
<?php $__env->startSection('heading', 'Perjanjian'); ?>

<?php $__env->startSection('content'); ?>
<section class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <form class="form form-vertical" method="post" action="<?php echo e(url('/admin/perjanjian-kerjasama/update')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" readonly required class="form-control" name="id" value="<?php echo e($data->id); ?>">
                    <div class="form-body">
                        <div class="row">
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="pks">Nama perjanjian (PKS) <span class="text-danger">*</span></label>
                                    <input type="text" id="pks" class="form-control" name="pks" required value="<?php echo e($data->pks); ?>">
                                </div>
                            </div>
                            <div class="col-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary mb-1">Submit</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/perjanjian/edit.blade.php ENDPATH**/ ?>