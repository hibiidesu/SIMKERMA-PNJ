<?php $__env->startComponent('mail::message'); ?>

# Pengajuan Anda dengan ID <?php echo e($kerjasama->id); ?> telah diterima oleh
<?php if($kerjasama->step == '3'): ?>
    Tim Legal
<?php elseif($kerjasama->step == '5'): ?>
    Wadir 4
<?php elseif($kerjasama->step == '7'): ?>
    Direktur !!!
<?php endif; ?>

**Detail Pengajuan:**


- Judul: <?php echo e($kerjasama->kerjasama); ?>

- Tanggal Pengajuan: <?php echo e($kerjasama->created_at->format('d-m-Y')); ?>

- Status: <?php if($kerjasama->step == '3'): ?>
Diterima Tim Legal (Menunggu review Wadir 4)
<?php elseif($kerjasama->step == '5'): ?>
Diterima Wadir 4 (Menunggu review Direktur)
<?php elseif($kerjasama->step == '7'): ?>
Diterima Direktur
<?php endif; ?>

<?php $__env->startComponent('mail::button', ['url' => env('APP_URL').'/<?php echo e($kerjasama->user->role->role_name); ?>/kerjasama/detail/'. $kerjasama->id], 'color::success'); ?>
Lihat Pengajuan
<?php echo $__env->renderComponent(); ?>

Terima kasih,
Politeknik Negeri Jakarta<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/mails/markdown/terimaPengajuan.blade.php ENDPATH**/ ?>