<?php $__env->startSection('heading', 'Review Kerja Sama'); ?>

<?php $__env->startSection('content'); ?>
<section class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <?php if(Auth::user()->role->role_name == 'admin'): ?>
                    <a href="<?php echo e(url('/admin/pengajuan-kerjasama/add')); ?>" class="btn btn-info"><i class="fas fa-plus"></i> &nbsp;Add New</a>
                <?php elseif(Auth::user()->role->role_name == 'pic'): ?>
                    <a href="<?php echo e(url('/pic/pengajuan-kerjasama/add')); ?>" class="btn btn-info"><i class="fas fa-plus"></i> &nbsp;Add New</a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <div class="message form">
                    <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <p><?php echo e(session('error')); ?></p>
                            </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(session('success')); ?></p>
                            </div>
                    <?php endif; ?>
                </div>
                <table class="table table-striped table-sm table-hover" id="datatable">
                    <thead>
                        <tr>
                            <th width="3%">No</th>
                            <th>Mitra</th>
                            <th>Judul</th>
                            <th>Nomor</th>
                            <th width="15%">Created at</th>
                            <th width="10%">Created by</th>
                            <th width="3%">Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($item->mitra); ?></td>
                            <?php if(Auth::user()->role->role_name == 'admin'): ?>
                            <td> <a href="<?php echo e(url('/admin/pengajuan-kerjasama/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php elseif(Auth::user()->role->role_name == 'legal'): ?>
                            <td> <a href="<?php echo e(url('/legal/review/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php elseif(Auth::user()->role->role_name == 'pemimpin'): ?>
                            <td> <a href="<?php echo e(url('/pemimpin/review/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php elseif(Auth::user()->role->role_name == 'direktur'): ?>
                            <td> <a href="<?php echo e(url('/direktur/review/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php elseif(Auth::user()->role->role_name == 'pic'): ?>
                            <td> <a href="<?php echo e(url('/pic/pengajuan-kerjasama/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php endif; ?>
                            <td><?php echo e($item->nomor); ?></td>
                            <td><?php echo e($item->created_at); ?></td>
                            <td>
                                <?php echo e($item->user->username); ?>

                            </td>
                            <td>
                                <?php if($item->step == '1'): ?>
                                    <span class="badge bg-warning text-dark mt-lg-0 mt-2">Menunggu Review Legal</span>
                                <?php elseif($item->step == '2'): ?>
                                    <?php if($item->catatan): ?>
                                        <span class="badge bg-danger text-white mt-lg-0 mt-2">Ditolak dengan Catatan Legal</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger text-white mt-lg-0 mt-2">Ditolak Legal</span>
                                    <?php endif; ?>
                                <?php elseif($item->step == '3'): ?>
                                    <span class="badge bg-warning text-white mt-lg-0 mt-2">Menunggu Review WD4</span>
                                <?php elseif($item->step == '4'): ?>
                                    <?php if($item->catatan): ?>
                                        <span class="badge bg-danger text-white mt-lg-0 mt-2">Ditolak dengan Catatan WD4</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger text-white mt-lg-0 mt-2">Ditolak WD4</span>
                                    <?php endif; ?>
                                <?php elseif($item->step == '5'): ?>
                                    <span class="badge bg-warning text-white mt-lg-0 mt-2">Menunggu Review Direktur</span>
                                <?php elseif($item->step == '6'): ?>
                                    <?php if($item->catatan): ?>
                                        <span class="badge bg-danger text-white mt-lg-0 mt-2">Ditolak dengan Catatan Direktur</span>
                                    <?php else: ?>
                                        <span class="badge bg-danger text-white mt-lg-0 mt-2">Ditolak Direktur</span>
                                    <?php endif; ?>
                                <?php elseif($item->step == '7'): ?>
                                    <span class="badge bg-success text-white mt-lg-0 mt-2">Diterima</span>
                                <?php endif; ?>
                            </td>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/review/index.blade.php ENDPATH**/ ?>