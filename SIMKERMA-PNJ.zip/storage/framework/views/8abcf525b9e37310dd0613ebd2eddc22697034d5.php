<?php $__env->startComponent('mail::message'); ?>

# Pengajuan Anda  <?php echo e($kerjasama); ?> Sedang Menunggu Untuk Di Review. <br>
**Detail Pengajuan:** <br>


- Judul: <?php echo e($kerjasama); ?> <br>
- Tanggal Pengajuan: <?php echo e($tanggal_pengajuan); ?> <br>
- Tanggal Kegiatan : <?php echo e($tanggal_mulai); ?> Sampai <?php echo e($tanggal_selesai); ?> <br>
- Kegiatan : <?php echo e($kegiatan); ?> <br>
- Sifat: <?php echo e($sifat); ?> <br>
- PIC PNJ : <?php echo e($pic_pnj); ?> <br>
- Status: Menunggu <br>

Thanks,<br>
<?php echo e(config('app.name')); ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/mails/markdown/pengajuanBaru.blade.php ENDPATH**/ ?>