
<?php $__env->startSection('heading', 'User'); ?>

<?php $__env->startSection('content'); ?>
<section class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <a href="<?php echo e(url('/admin/user/add')); ?>" class="btn btn-info"><i class="fas fa-plus"></i> &nbsp;Add New</a>
            </div>
            <div class="card-body">
                <div class="message form">
                    <?php if(session('error')): ?>
                            <div class="alert alert-danger">
                                <p><?php echo e(session('error')); ?></p>
                            </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                            <div class="alert alert-success">
                                <p><?php echo e(session('success')); ?></p>
                            </div>
                    <?php endif; ?>
                </div>
                <table class="table table-striped w-100" id="datatable">
                    <thead>
                        <tr>
                            <th width="3%">No</th>
                            <th>Username</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($item->username); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td><?php echo e($item->role->role_name); ?></td>
                            <td>
                                <div class="d-flex">
                                    <a href="<?php echo e(url('/admin/user/edit/'. $item->id)); ?>" class="btn btn-primary">Edit</a>
                                    <?php if($item->status == 0): ?>
                                        <a href="<?php echo e(url('/admin/user/activate/'. $item->id)); ?>" class="btn btn-success ms-2">Aktifkan</a>
                                    <?php else: ?>
                                        <a href="<?php echo e(url('/admin/user/deactivate/'. $item->id)); ?>" class="btn btn-danger ms-2">nonaktifkan</a>
                                    <?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/user/index.blade.php ENDPATH**/ ?>