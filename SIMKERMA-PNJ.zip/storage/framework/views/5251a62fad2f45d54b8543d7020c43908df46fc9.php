<?php $__env->startSection('heading', 'Kerja Sama'); ?>

<?php $__env->startSection('content'); ?>
<section class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <div class="message form">
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger">
                            <p><?php echo e(session('error')); ?></p>
                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success">
                            <p><?php echo e(session('success')); ?></p>
                        </div>
                    <?php endif; ?>
                </div>

                <?php if(Request::get('filter')): ?>
                    <?php if(Auth::check() && Auth::user()->role->role_name == 'admin'): ?>
                        <a href="<?php echo e(url('admin/kerjasama/export'.str_replace(url('/admin/kerjasama'), '', URL::full()))); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-file-excel"></i> Generate Excel</a>
                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pemimpin'): ?>
                        <a href="<?php echo e(url('pemimpin/kerjasama/export'.str_replace(url('/pemimpin/kerjasama'), '', URL::full()))); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-file-excel"></i> Generate Excel</a>
                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pic'): ?>
                        <a href="<?php echo e(url('pemimpin/kerjasama/export'.str_replace(url('/pic/kerjasama'), '', URL::full()))); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-file-excel"></i> Generate Excel</a>
                    <?php endif; ?>
                <?php else: ?>
                    <?php if(Auth::check() && Auth::user()->role->role_name == 'admin'): ?>
                        <a href="<?php echo e(url('admin/kerjasama/export')); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-file-excel"></i> Generate Excel</a>
                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pemimpin'): ?>
                        <a href="<?php echo e(url('pemimpin/kerjasama/export')); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-file-excel"></i> Generate Excel</a>
                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pic'): ?>
                        <a href="<?php echo e(url('pic/kerjasama/export')); ?>" class="btn btn-primary" style="float: right;"><i class="fas fa-file-excel"></i> Generate Excel</a>
                    <?php endif; ?>
                <?php endif; ?>

                <form action="" method="get">
                    <h5>Filter:</h5>
                    <div class="d-flex flex-column flex-md-row gap-md-3">
                        <div class="form-group">
                            <label for="date">Masa Berlaku</label>
                            <div class="mt-md-1">
                                <select name="date" id="date" class="form-select">
                                    <option value="1" <?php echo e(Request::get('date') == '1' ? 'selected' : ''); ?>>Semua</option>
                                    <option value="2" <?php echo e(Request::get('date') == '2' ? 'selected' : ''); ?>>Masih Berlaku</option>
                                    <option value="3" <?php echo e(Request::get('date') == '3' ? 'selected' : ''); ?>>Segera Berakhir</option>
                                    <option value="4" <?php echo e(Request::get('date') == '4' ? 'selected' : ''); ?>>Sudah Berakhir</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="sifat">Sifat</label>
                            <div class="mt-md-1">
                                <select name="sifat" id="sifat" class="form-select">
                                    <option value="all" <?php echo e(Request::get('sifat') == 'all' ? 'selected' : ''); ?>>Semua</option>
                                    <option value="Lokal" <?php echo e(Request::get('sifat') == 'Lokal' ? 'selected' : ''); ?>>Lokals</option>
                                    <option value="Nasional" <?php echo e(Request::get('sifat') == 'Nasional' ? 'selected' : ''); ?>>Nasional</option>
                                    <option value="Internasional" <?php echo e(Request::get('sifat') == 'Internasional' ? 'selected' : ''); ?>>Internasional</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="type">Jenis Kerja Sama</label>
                            <div class="mt-md-1">
                                <select class="form-select" required id="type" name="type">
                                    <option value="all">Semua</option>
                                    <?php $__currentLoopData = $jenisKerjasama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id + 1); ?>" <?php echo e(Request::get('type') == $item->id + 1 ? 'selected' : ''); ?>><?php echo e($item->jenis_kerjasama); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="mt-md-1">
                                <button class="btn btn-primary mt-4" type="submit" name="filter" value="true">Terapkan</button>
                                <?php if(Request::get('filter')): ?>
                                    <?php if(Auth::check() && Auth::user()->role->role_name == 'admin'): ?>
                                        <a href="<?php echo e(url('admin/kerjasama')); ?>" class="btn btn-secondary mt-4" title="Hapus Filter"><i class="fas fa-times"></i></a>
                                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pemimpin'): ?>
                                        <a href="<?php echo e(url('pemimpin/kerjasama')); ?>" class="btn btn-secondary mt-4" title="Hapus Filter"><i class="fas fa-times"></i></a>
                                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'legal'): ?>
                                        <a href="<?php echo e(url('legal/kerjasama')); ?>" class="btn btn-secondary mt-4" title="Hapus Filter"><i class="fas fa-times"></i></a>
                                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'direktur'): ?>
                                        <a href="<?php echo e(url('direktur/kerjasama')); ?>" class="btn btn-secondary mt-4" title="Hapus Filter"><i class="fas fa-times"></i></a>
                                    <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pic'): ?>
                                        <a href="<?php echo e(url('pic/kerjasama')); ?>" class="btn btn-secondary mt-4" title="Hapus Filter"><i class="fas fa-times"></i></a>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </form>
                <hr>
                <table class="table table-striped table-sm table-sm" id="datatable">
                    <thead>
                        <tr>
                            <th width="3%">No</th>
                            <th>Nama Mitra</th>
                            <th>Kerjasama</th>
                            <th>Nomor</th>
                            <th>Tanggal Berlaku</th>
                            <th>Sifat</th>
                            <th>Jenis Kerja Sama</th>
                            <th>Jenis Perjanjian</th>
                            <th>Unit</th>
                            <th>Prodi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($loop->index + 1); ?></td>
                            <td><?php echo e($item->mitra); ?></td>
                            <?php if(Auth::user()->role->role_name == 'admin'): ?>
                            <td> <a href="<?php echo e(url('/admin/kerjasama/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php elseif(Auth::user()->role->role_name == 'pemimpin'): ?>
                            <td> <a href="<?php echo e(url('/pemimpin/kerjasama/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php elseif(Auth::user()->role->role_name == 'pic'): ?>
                            <td> <a href="<?php echo e(url('/pic/kerjasama/detail/'. $item->id)); ?>" ><?php echo e($item->kerjasama); ?></a>   </td>
                            <?php endif; ?>
                            <td><?php echo e($item->nomor); ?></td>
                            <td>
                                <?php if($item->tanggal_selesai > date('Y-m-d')): ?>
                                    <?php if(date('Y') - date('Y', strtotime($item->tanggal_selesai)) == 0 && date('m') - date('m', strtotime($item->tanggal_selesai)) >= -3): ?>
                                        <span class="badge bg-warning text-dark">
                                            <?php echo e(date('Y/m/d', strtotime($item->tanggal_mulai)).' - '. date('Y/m/d', strtotime($item->tanggal_selesai))); ?>

                                        </span>
                                    <?php else: ?>
                                        <span class="badge bg-success">
                                            <?php echo e(date('Y/m/d', strtotime($item->tanggal_mulai)).' - '. date('Y/m/d', strtotime($item->tanggal_selesai))); ?>

                                        </span>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="badge bg-danger">
                                        <?php echo e(date('Y/m/d', strtotime($item->tanggal_mulai)).' - '. date('Y/m/d', strtotime($item->tanggal_selesai))); ?>

                                    </span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->sifat == 'Nasional'): ?>
                                    <span class="badge bg-info text-dark mt-lg-0 mt-2"><?php echo e($item->sifat); ?></span>
                                <?php elseif($item->sifat == 'Internasional'): ?>
                                    <span class="badge bg-primary mt-lg-0 mt-2"><?php echo e($item->sifat); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($item->jenis_kerjasama->jenis_kerjasama); ?></td>
                            <td>
                                <?php $__currentLoopData = explode(',', $item->pks); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($loop->index + 1 < count(explode(',', $item->pks))): ?>
                                    <?php echo e($perjanjian[$x].', '); ?>

                                    <?php else: ?>
                                    <?php echo e($perjanjian[$x]); ?>

                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </td>
                            <td>
                                <?php if($item->jurusan): ?>
                                    <?php $__currentLoopData = explode(',', $item->jurusan); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index + 1 < count(explode(',', $item->jurusan))): ?>
                                        <?php echo e($unit[$x].', '); ?>

                                        <?php else: ?>
                                        <?php echo e($unit[$x]); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($item->prodi): ?>
                                    <?php $__currentLoopData = explode(',', $item->prodi); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($loop->index + 1 < count(explode(',', $item->prodi))): ?>
                                        <?php echo e($prodi[$x].', '); ?>

                                        <?php else: ?>
                                        <?php echo e($prodi[$x]); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/kerjasama/index.blade.php ENDPATH**/ ?>