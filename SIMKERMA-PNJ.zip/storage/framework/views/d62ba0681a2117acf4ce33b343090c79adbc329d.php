<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="description" content="Sistem Kerja Sama (SIMKERMA) PNJ menyajikan data historis kerja sama Politeknik Negeri Jakarta" />
    <meta name="keywords" content="Sistem Informasi Kerja Sama Politeknik Negeri Jakarta" />
    <link rel="shortcut icon" href="<?php echo e(asset('favicon.png')); ?>">
    <title>Kerja Sama Politeknik Negeri Jakarta [TEST]</title>
    <script src="<?php echo e(asset('js/jquery-3.6.0.min.js')); ?>"></script>
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;600;700;800&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Viga" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/jquery-datatables/jquery.dataTables.bootstrap5.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/perfect-scrollbar/perfect-scrollbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/bootstrap-icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('admin/vendors/fontawesome/all.min.css')); ?>">
    <?php echo $__env->yieldContent('styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/app.css')); ?>">
    <style>
        .sidebar-wrapper {
            width: 260px
        }
        #main {
            margin-left: 260px;
        }
        .sidebar-wrapper .menu {
            padding: 0 0.5rem;
        }
        table.dataTable td, table.table-sm td {
            padding: 15px 8px !important;
        }
        .form-control.is-invalid~.form-control-icon {
            top: 32%;
        }
    </style>
</head>
<body>
    <?php if(url()->current() != url('/login') && url()->current() != url('/password/reset')): ?>
        <div id="app">
            <?php if(Auth::check() && Auth::user()->role->role_name == 'admin'): ?>
                <?php echo $__env->make('layouts.sidebar-admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pemimpin'): ?>
                <?php echo $__env->make('layouts.sidebar-pemimpin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Auth::check() && Auth::user()->role->role_name == 'pic'): ?>
                <?php echo $__env->make('layouts.sidebar-pic', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Auth::check() && Auth::user()->role->role_name == 'legal'): ?>
                <?php echo $__env->make('layouts.sidebar-legal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php elseif(Auth::check() && Auth::user()->role->role_name == 'direktur'): ?>
                <?php echo $__env->make('layouts.sidebar-direktur', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endif; ?>

            <div id="main">
                <header class="mb-3">
                    <a href="#" class="burger-btn d-block d-xl-none">
                        <i class="bi bi-justify fs-3"></i>
                    </a>
                </header>
                <div class="page-heading">
                    <h3><?php echo $__env->yieldContent('heading'); ?></h3>
                </div>
                <div class="page-content">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>
                
            </div>
        </div>
    <?php else: ?>
        <?php echo $__env->yieldContent('content-auth'); ?>
    <?php endif; ?>

    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="<?php echo e(asset('admin/vendors/perfect-scrollbar/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/jquery-datatables/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/jquery-datatables/custom.jquery.dataTables.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/vendors/fontawesome/all.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/mazer.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/js/extensions/sweetalert2.js')); ?>"></script>
    <script>
        $("#datatable").DataTable({
            "scrollX": true,
            "lengthMenu": [
                [10, 50, 75, -1],
                [10, 50, 75, "All"]
            ]
        });
    </script>
</body>
</html>
<?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/layouts/app.blade.php ENDPATH**/ ?>