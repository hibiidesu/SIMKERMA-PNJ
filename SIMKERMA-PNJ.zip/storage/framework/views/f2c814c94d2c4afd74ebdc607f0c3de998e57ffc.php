<?php $__env->startSection('heading', 'Kerja Sama'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('admin/vendors/choices.js/choices.min.css')); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section class="row">
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <?php if(Auth::user()->role->role_name == 'admin'): ?>
                        <form class="form form-vertical" method="post" action="<?php echo e(url('/admin/pengajuan-kerjasama/store')); ?>"
                            enctype="multipart/form-data">
                        <?php elseif(Auth::user()->role->role_name == 'pic'): ?>
                            <form class="form form-vertical" method="post"
                                action="<?php echo e(url('/pic/pengajuan-kerjasama/store')); ?>" enctype="multipart/form-data">
                    <?php endif; ?>
                    <?php echo csrf_field(); ?>
                    <div class="form-body">
                        <div class="row">
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="kerjasama">Nama Mitra<span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="mitra" class="form-control" name="mitra" required
                                        value="<?php echo e(old('mitra')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="kerjasama">Kerja sama <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="kerjasama" class="form-control" name="kerjasama" required
                                        value="<?php echo e(old('kerjasama')); ?>">
                                </div>
                            </div>
                            <div class="col-6 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="tanggal_mulai">tanggal mulai <span
                                            class="text-danger">*</span></label>
                                    <input type="date" id="tanggal_mulai" class="form-control" name="tanggal_mulai"
                                        required value="<?php echo e(old('tanggal_mulai')); ?>">
                                </div>
                            </div>
                            <div class="col-6 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="tanggal_selesai">tanggal selesai <span
                                            class="text-danger">*</span></label>
                                    <input type="date" id="tanggal_selesai" class="form-control" name="tanggal_selesai"
                                        required value="<?php echo e(old('tanggal_selesai')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="nomor">nomor <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="nomor" class="form-control" name="nomor" required
                                        value="<?php echo e(old('nomor')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="kegiatan">kegiatan</label>
                                    <textarea id="kegiatan" class="form-control" name="kegiatan" rows="3"><?php echo e(old('kegiatan')); ?></textarea>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="kerjasama">Sifat (Lokal / Nasional /
                                        Internasional) <span class="text-danger">*</span></label>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sifat" id="sifat0"
                                            value="Lokal" required <?php echo e(old('sifat') == 'Lokal' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="sifat0">
                                            Lokal
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sifat" id="sifat1"
                                            value="Nasional" required <?php echo e(old('sifat') == 'Nasional' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="sifat1">
                                            Nasional
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="sifat" id="sifat2"
                                            value="Internasional" <?php echo e(old('sifat') == 'Internasional' ? 'checked' : ''); ?>>
                                        <label class="form-check-label" for="sifat2">
                                            Internasional
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="jenis_kerjasama_id">Jenis Kerja sama
                                        <span class="text-danger">*</span></label>
                                    <select class="form-select" required id="jenis_kerjasama_id"
                                        name="jenis_kerjasama_id">
                                        <option value="">-</option>
                                        <?php $__currentLoopData = $jenisKerjasama; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e(old('jenis_kerjasama_id') && old('jenis_kerjasama_id') == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->jenis_kerjasama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="kriteria_mitra_id">Kriteria
                                        Mitra<span class="text-danger">*</span></label>
                                    <select class="form-select" required id="kriteria_mitra_id" name="kriteria_mitra_id">
                                        <option value="">-</option>
                                        <?php $__currentLoopData = $kriteria_mitra; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e(old('kriteria_mitra_id') && old('kriteria_mitra_id') == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->kriteria_mitra); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="kriteria_kemitraan_id">Kriteria
                                        Mitra<span class="text-danger">*</span></label>
                                    <select class="form-select" required id="kriteria_kemitraan_id"
                                        name="kriteria_kemitraan_id">
                                        <option value="">-</option>
                                        <?php $__currentLoopData = $kriteria_kemitraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e(old('kriteria_kemitraan_id') && old('kriteria_kemitraan_id') == $item->id ? 'selected' : ''); ?>>
                                                <?php echo e($item->kriteria_kemitraan); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="perjanjian">Jenis Perjanjian <span
                                            class="text-danger">*</span></label>
                                    <select class="choices form-select" multiple="multiple" id="perjanjian"
                                        name="perjanjian[]" multiple required>
                                        <?php $__currentLoopData = $perjanjian; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e(old('perjanjian') && in_array($item->id, old('perjanjian')) ? 'selected' : ''); ?>>
                                                <?php echo e($item->pks); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="jurusan">Unit<span
                                            class="text-danger">*</span></label>
                                    <select class="choices-2 form-select" multiple="multiple" id="jurusan"
                                        name="jurusan[]" multiple required>
                                        <?php $__currentLoopData = $unit; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"
                                                <?php echo e(old('jurusan') && in_array($item->id, old('jurusan')) ? 'selected' : ''); ?>>
                                                <?php echo e($item->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <label class="mb-2 fw-bold text-capitalize" for="prodi">Prodi</label>
                                <select id="prodi" name="prodi[]" multiple>
                                </select>
                                <div id="prodi-loading" style="display: none;">
                                    <small class="text-muted">Memuat data prodi...</small>
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="pic_pnj">Nama PIC PNJ <span
                                            class="text-danger">*</span></label>
                                    <input type="text" id="pic_pnj" class="form-control" name="pic_pnj" required
                                        value="<?php echo e(auth::user()->name); ?>" disabled>
                                    <input type="hidden" name="pic_pnj" value="<?php echo e(auth::user()->name); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="alamat_perusahaan">Alamat Perusahaan
                                        <span class="text-danger">*</span></label>
                                    <input type="text" id="alamat_perusahaan" class="form-control"
                                        name="alamat_perusahaan" required value="<?php echo e(old('alamat_perusahaan')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="pic_industri">Nama PIC Industri/PT
                                        <span class="text-danger">*</span></label>
                                    <input type="text" id="pic_industri" class="form-control" name="pic_industri"
                                        required value="<?php echo e(old('pic_industri')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="jabatan_pic_industri">Jabatan PIC
                                        Industri/PT <span class="text-danger">*</span></label>
                                    <input type="text" id="jabatan_pic_industri" class="form-control"
                                        name="jabatan_pic_industri" required value="<?php echo e(old('jabatan_pic_industri')); ?>">
                                </div>
                            </div>

                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="telp_industri">Telp. PIC
                                        Industri</label>
                                    <input type="tel" id="telp_industri" class="form-control" name="telp_industri"
                                        value="<?php echo e(old('telp_industri')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-2">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="email">Email</label>
                                    <input type="email" id="email" class="form-control" name="email"
                                        value="<?php echo e(old('email')); ?>">
                                </div>
                            </div>
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label class="mb-2 fw-bold text-capitalize" for="file">Surat Kerja sama <span
                                            class="text-danger">*</span></label>
                                    <input type="file" id="file" class="form-control" name="file" required
                                        accept="application/pdf">
                                </div>
                            </div>
                            <hr>
                            
                            <div class="col-12 d-flex justify-content-end">
                                <button type="submit" class="btn btn-primary mb-1">Submit</button>
                            </div>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<script>
    $(document).ready(function() {
        // Inisialisasi Choices.js untuk prodi
        const prodiElement = document.getElementById('prodi');
        const prodiChoice = new Choices(prodiElement, {
            removeItemButton: true,
            searchEnabled: true
        });

        // Handler untuk perubahan unit
        $('#jurusan').on('change', function() {
            const selectedUnits = $(this).val();

            prodiChoice.clearStore();
            prodiChoice.setChoices([{
                value: '',
                label: '--- Memuat data prodi... ---',
                disabled: true
            }]);

            if (selectedUnits && selectedUnits.length > 0) {
                $.ajax({
                    url: `/api/prodi/find/${selectedUnits.join(',')}`,
                    method: 'GET',
                    dataType: 'json',
                    beforeSend: function() {
                        $('#prodi-loading').show();
                    },
                    success: function(response) {
                        if (response.status === 'success' && response.data.length > 0) {
                            prodiChoice.clearStore();
                            prodiChoice.setChoices(
                                response.data.map(prodi => ({
                                    value: prodi.id.toString(),
                                    label: prodi.name
                                })),
                                'value',
                                'label',
                                false
                            );
                        } else {
                            prodiChoice.clearStore();
                            prodiChoice.setChoices([{
                                value: '',
                                label: 'Tidak ada prodi tersedia',
                                disabled: true
                            }]);
                        }
                    },
                    error: function(xhr) {
                        console.error('Error:', xhr);
                        prodiChoice.clearStore();
                        prodiChoice.setChoices([{
                            value: '',
                            label: 'Terjadi kesalahan saat mengambil data',
                            disabled: true
                        }]);
                    },
                    complete: function() {
                        $('#prodi-loading').hide();
                    }
                });
            } else {
                prodiChoice.clearStore();
                prodiChoice.setChoices([{
                    value: '',
                    disabled: true
                }]);
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('admin/vendors/jquery/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/vendors/choices.js/choices.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/pages/form-element-select.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIMKERMA-PNJ\resources\views/review/add.blade.php ENDPATH**/ ?>