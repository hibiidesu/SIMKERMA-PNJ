[SITE](https://simkerma.scz.my.id)

## FITUR YANG DIBUTUHKAN
1. Semua Request kerjasama harus di review dan diterima oleh semua pemimpin sebelum akhirnya benar benar diterima
2. API Untuk mengcek status kerjasama
3. Notifikasi Email