<?php

namespace App\Http\Controllers;

use App\Mail\pengajuanBaru;
use Illuminate\Support\Facades\Auth;
use App\Models\Jenis_kerjasama;
use App\Models\Kerjasama;
use App\Models\kriteria_kemitraan;
use App\Models\kriteria_mitra;
use App\Models\pks;
use App\Models\Unit;
use App\Models\User;
use App\Models\Prodi;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Persetujuan;
use Illuminate\Support\Facades\Mail;



class ReviewController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        $perjanjian = [];
        foreach (pks::all() as $item) {
            $perjanjian[$item->id] = $item->pks;
        }
        if (Auth::user()->role_id == 3) {
            return view('review/index', [
                'perjanjian' => $perjanjian,
                'data' => Kerjasama::where('step', '=', '1')
                    ->where('target_reviewer_id', 'like', '%' . Auth::user()->id . '%')
                    ->orWhereNull('target_reviewer_id')
                    ->where('step', '=', '1')
                    ->orderBy('created_at', 'desc')
                    ->get(),
            ]);
        } else if (Auth::user()->role_id == 2) {
            return view('review/index', [
                'perjanjian' => $perjanjian,
                'data' => Kerjasama::where('step', '=', '3')
                    ->where('target_reviewer_id', 'like', '%' . Auth::user()->id . '%')
                    ->orWhereNull('target_reviewer_id')
                    ->where('step', '=', '3')
                    ->orderBy('created_at', 'desc')
                    ->get(),
            ]);
        } else if (Auth::user()->role_id == 5) {
            return view('review/index', [
                'perjanjian' => $perjanjian,
                'data' => Kerjasama::where('step', '=', '5')
                    ->where('target_reviewer_id', 'like', '%' . Auth::user()->id . '%')
                    ->orWhereNull('target_reviewer_id')
                    ->where('step', '=', '5')
                    ->orderBy('created_at', 'desc')
                    ->get(),
            ]);
        } else {
            return view('review/index', [
                'perjanjian' => $perjanjian,
                'data' => Kerjasama::where('user_id', '=', Auth::user()->id)->orderBy('step', 'asc')->get(),
            ]);
        }
    }

    public function create()
    {
        if(Auth::user()->role_id == 2){

            return view('review/add', [
                'users' => User::where('role_id', '=', '2')->get(),
                'kriteria_mitra' => kriteria_mitra::all(),
                'kriteria_kemitraan' => kriteria_kemitraan::all(),
                'unit' => Unit::all(),
                'prodi' => Prodi::all(),
                'perjanjian' => pks::all(),
                'jenisKerjasama' => Jenis_kerjasama::all(),
            ]);

        } else if(Auth::user()->role_id == 3){

            return view('review/add', [
                'users' => User::where('role_id', '=', '3')->get(),
                'kriteria_mitra' => kriteria_mitra::all(),
                'kriteria_kemitraan' => kriteria_kemitraan::all(),
                'unit' => Unit::all(),
                'prodi' => Prodi::all(),
                'perjanjian' => pks::all(),
                'jenisKerjasama' => Jenis_kerjasama::all(),
            ]);

        } else if(Auth::user()->role_id == 5){

            return view('review/add', [
                'users' => User::where('role_id', '=', '5')->get(),
                'kriteria_mitra' => kriteria_mitra::all(),
                'kriteria_kemitraan' => kriteria_kemitraan::all(),
                'unit' => Unit::all(),
                'prodi' => Prodi::all(),
                'perjanjian' => pks::all(),
                'jenisKerjasama' => Jenis_kerjasama::all(),
            ]);

        }

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $request->validate(
            [
                'mitra' => 'required',
                'kerjasama' => 'required',
                'tanggal_mulai' => 'required|date',
                'tanggal_selesai' => 'required|date|after:tanggal_mulai',
                'nomor' => 'required',
                'sifat' => 'required',
                'jenis_kerjasama_id' => 'required',
                'kriteria_mitra_id' => 'required',
                'kriteria_kemitraan_id' => 'required',
                'perjanjian' => 'required',
                'jurusan' => 'required',
                'prodi' => 'required',
                'pic_pnj' => 'required',
                'alamat_perusahaan' => 'required',
                'pic_industri' => 'required',
                'jabatan_pic_industri' => 'required',
                // 'telp_industri' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                // 'email' => 'required|email',
                'file' => 'required|file|mimes:pdf,doc,docx',
            ],
            ['telp_industri.regex' => 'format nomor telpon tidak valid']
        );

        if ($request->telp_industri) {
            $request->validate([
                'telp_industri' => 'regex:/^([0-9\s\-\+\(\)]*)$/',
            ]);
        }
        $file = $request->file('file');
        $nama_file = time() . "_" . $file->getClientOriginalName();
        $move = Storage::disk('surat_kerjasama')->put($nama_file, file_get_contents($file));
        if ($move) {
            $kerjasama = Kerjasama::create([
                'mitra' => $request->mitra,
                'kerjasama' => $request->kerjasama,
                'tanggal_mulai' => $request->tanggal_mulai,
                'tanggal_selesai' => $request->tanggal_selesai,
                'nomor' => $request->nomor,
                'kegiatan' => $request->kegiatan,
                'sifat' => $request->sifat,
                'user_id' => Auth::user()->id,
                'jenis_kerjasama_id' => $request->jenis_kerjasama_id,
                'kriteria_mitra_id' => $request->kriteria_mitra_id,
                'kriteria_kemitraan_id' => $request->kriteria_kemitraan_id,
                'pks' => implode(',', $request->perjanjian),
                'jurusan' => implode(',', $request->jurusan),
                'prodi' => implode(',', $request->prodi),
                'target_reviewer_id' => $request->target_reviewer ? implode(',', $request->target_reviewer) : null,
                'pic_pnj' => $request->pic_pnj,
                'alamat_perusahaan' => $request->alamat_perusahaan,
                'pic_industri' => $request->pic_industri,
                'jabatan_pic_industri' => $request->jabatan_pic_industri,
                'telp_industri' => $request->telp_industri,
                'email' => $request->email,
                'file' => $nama_file,
                'step' => 1,
            ]);

            // Buat persetujuan untuk setiap pemimpin
            $LegalUsers = User::where('role_id', 3)->get();
            foreach ($LegalUsers as $legal) {
                Persetujuan::create([
                    'kerjasama_id' => $kerjasama->id,
                    'user_id' => $legal->id,
                    'status' => 'menunggu',
                ]);
                Mail::to($legal->email)->send(new pengajuanBaru(
                    $request->kerjasama,
                    $request->tanggal_mulai,
                    $request->tanggal_selesai,
                    $request->kegiatan,
                    $request->sifat,
                    $request->pic_pnj,
                ));
            }
            if (Auth::user()->role->role_name == 'pic') {
                return redirect('/pic/pengajuan-kerjasama')->with('success', 'Data berhasil ditambahkan dan menunggu persetujuan pemimpin');
            }  else {
                return redirect('/admin/pengajuan-kerjasama')->with('success', 'Data berhasil ditambahkan dan menunggu persetujuan pemimpin');
            }

        } else {
            if (Auth::user()->role->role_name == 'pic') {
                return redirect('/pic/pengajuan-kerjasama')->with('error', 'Data gagal ditambahkan');
            } else {
                return redirect('/admin/pengajuan-kerjasama')->with('error', 'Data gagal ditambahkan');
            }

        }
    }

    public function show($id)
    {
        if (Auth::user()->role_id == 3) {
            $data = Kerjasama::where('target_reviewer_id', 'like', '%' . Auth::user()->id . '%')
                ->where('id', '=', $id)
                ->where('step', '=', '1')
                ->orWhereNull('target_reviewer_id')
                ->where('id', '=', $id)
                ->where('step', '=', '1')
                ->get()
                ->first();
        } else if (Auth::user()->role_id == 2) {
            $data = Kerjasama::where('target_reviewer_id', 'like', '%' . Auth::user()->id . '%')
                ->where('id', '=', $id)
                ->where('step', '=', '3')
                ->orWhereNull('target_reviewer_id')
                ->where('id', '=', $id)
                ->where('step', '=', '3')
                ->get()
                ->first();
        } else if (Auth::user()->role_id == 5) {

            $data = Kerjasama::where('target_reviewer_id', 'like', '%' . Auth::user()->id . '%')
                ->where('id', '=', $id)
                ->where('step', '=', '5')
                ->orWhereNull('target_reviewer_id')
                ->where('id', '=', $id)
                ->where('step', '=', '5')
                ->get()
                ->first();

        } else {
            $data = Kerjasama::findOrFail($id);
        }
        if ($data) {
            $unit = "";
            $prodi = "";
            if ($data->jurusan != '') {
                $unit = Unit::whereIn('id', explode(',', $data->jurusan))->get();
            }
            if ($data->prodi != '') {
                $prodi = Prodi::whereIn('id', explode(',', $data->prodi))->get();
            }
            $perjanjian = pks::whereIn('id', explode(',', $data->pks))->get();

            return view('review/detail', [
                'unit' => $unit,
                'prodi' => $prodi,
                'perjanjian' => $perjanjian,
                'data' => $data,
            ]);
        } else {
            if (Auth::user()->role_id == 2) {
                return redirect('/pemimpin/review')->with('error', 'Akses tidak diizinkan');
            } else if (Auth::user()->role_id == 3) {
                return redirect('/legal/review')->with('error', 'Akses tidak diizinkan');
            } else if (Auth::user()->role_id == 5) {
                return redirect('/direktur/review')->with('error', 'Akses tidak diizinkan');
            } else {
                return redirect('/admin/pengajuan-kerjasama')->with('error', 'Akses tidak diizinkan');
            }
        }
    }

    public function tolakLegal(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'catatan' => 'required',
        ]);
        $kerjasama = Kerjasama::findOrFail($request->id);
        $update = $kerjasama->update([
            'catatan' => $request->catatan,
            'step' => '2',
            'reviewer_id' => Auth::user()->id,
        ]);
        if ($update) {
            mail::to($kerjasama->user->email)->send(new \App\Mail\tolakPengajuan($kerjasama,$request->catatan));
            mail::to($kerjasama->email)->send(new \App\Mail\tolakPengajuanMitra($kerjasama,$request->catatan));
            return redirect('/pemimpin/review')->with('success', 'Data berhasil ditolak');
        } else {
            return redirect('/pemimpin/review')->with('error', 'Data gagal ditolak');
        }
    }
    public function tolakWadir(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'catatan' => 'required',
        ]);
        $kerjasama = Kerjasama::findOrFail($request->id);
        $update = $kerjasama->update([
            'catatan' => $request->catatan,
            'step' => '4',
            'reviewer_id' => Auth::user()->id,
        ]);
        if ($update) {
            mail::to($kerjasama->user->email)->send(new \App\Mail\tolakPengajuan($kerjasama,$request->catatan));
            mail::to($kerjasama->email)->send(new \App\Mail\tolakPengajuanMitra($kerjasama,$request->catatan));
            return redirect('/pemimpin/review')->with('success', 'Data berhasil ditolak');
        } else {
            return redirect('/pemimpin/review')->with('error', 'Data gagal ditolak');
        }
    }

    public function tolakDirektur(Request $request)
    {
        $request->validate([
            'id' => 'required',
            'catatan' => 'required',
        ]);
        $kerjasama = Kerjasama::findOrFail($request->id);
        $update = $kerjasama->update([
            'catatan' => $request->catatan,
            'step' => '6',
            'reviewer_id' => Auth::user()->id,
        ]);
        if ($update) {
            mail::to($kerjasama->user->email)->send(new \App\Mail\tolakPengajuan($kerjasama,$request->catatan));
            mail::to($kerjasama->email)->send(new \App\Mail\tolakPengajuanMitra($kerjasama,$request->catatan));
            return redirect('/pemimpin/review')->with('success', 'Data berhasil ditolak');
        } else {
            return redirect('/pemimpin/review')->with('error', 'Data gagal ditolak');
        }
    }

    public function terimaLegal($id)
    {
        $kerjasama = Kerjasama::findOrFail($id);
        $update = $kerjasama->update([
            'step' => '3', // current_step + 2
            'reviewer_id' => Auth::user()->id,
        ]);
        if ($update) {
            mail::to($kerjasama->user->email)->send(new \App\Mail\terimaPengajuan($kerjasama));
            mail::to($kerjasama->email)->send(new \App\Mail\terimaPengajuanMitra($kerjasama));
            return redirect('/legal/review')->with('success', 'Data berhasil diterima');
        } else {
            return redirect('/legal/review')->with('error', 'Data gagal diterima');
        }
    }

    public function terimaWadir($id)
    {
        $kerjasama = Kerjasama::findOrFail($id);
        $update = $kerjasama->update([
            'step' => '5',
            'reviewer_id' => Auth::user()->id,
        ]);
        if ($update) {
            mail::to($kerjasama->user->email)->send(new \App\Mail\terimaPengajuan($kerjasama));
            mail::to($kerjasama->email)->send(new \App\Mail\terimaPengajuanMitra($kerjasama));
            return redirect('/pemimpin/review')->with('success', 'Data berhasil diterima');
        } else {
            return redirect('/pemimpin/review')->with('error', 'Data gagal diterima');
        }
    }

    public function terimaDirektur($id)
    {
        $kerjasama = Kerjasama::findOrFail($id);
        $update = $kerjasama->update([
            'step' => '7', // current_step + 2
            'reviewer_id' => Auth::user()->id,
        ]);
        if ($update) {
            mail::to($kerjasama->user->email)->send(new \App\Mail\terimaPengajuan($kerjasama));
            mail::to($kerjasama->email)->send(new \App\Mail\terimaPengajuanMitra($kerjasama));
            return redirect('/direktur/review')->with('success', 'Data berhasil diterima');
        } else {
            return redirect('/direktur/review')->with('error', 'Data gagal diterima');
        }
    }


    public function edit($id)
    {

        if (Auth::user()->role_id == 2) {
            return view('review/edit', [
                'users' => User::where('role_id', '=', '2')->get(),
                'perjanjian' => pks::all(),
                'unit' => Unit::all(),
                'prodi' => Prodi::all(),
                'data' => Kerjasama::findOrFail($id),
                'jenisKerjasama' => Jenis_kerjasama::all(),
            ]);

        } else if (Auth::user()->role_id == 3) {
            return view('review/edit', [
                'users' => User::where('role_id', '=', '3')->get(),
                'perjanjian' => pks::all(),
                'unit' => Unit::all(),
                'prodi' => Prodi::all(),
                'data' => Kerjasama::findOrFail($id),
                'jenisKerjasama' => Jenis_kerjasama::all(),
            ]);

        } else if (Auth::user()->role_id == 5) {
            return view('review/edit', [
                'users' => User::where('role_id', '=', '5')->get(),
                'perjanjian' => pks::all(),
                'unit' => Unit::all(),
                'prodi' => Prodi::all(),
                'data' => Kerjasama::findOrFail($id),
                'jenisKerjasama' => Jenis_kerjasama::all(),
            ]);

        }
    }

    public function update(Request $request, Kerjasama $kerjasama)
    {
        $request->validate(
            [
                'id' => 'required',
                'kerjasama' => 'required',
                'tanggal_mulai' => 'required|date',
                'tanggal_selesai' => 'required|date|after:tanggal_mulai',
                'nomor' => 'required',
                'kegiatan' => 'nullable',
                'sifat' => 'required',
                'jenis_kerjasama_id' => 'required',
                'perjanjian' => 'required',
                'jurusan' => 'required',
                'pic_pnj' => 'required',
                'alamat_perusahaan' => 'required',
                'pic_industri' => 'required',
                'jabatan_pic_industri' => 'required',
                // 'telp_industri' => 'required|regex:/^([0-9\s\-\+\(\)]*)$/|min:10',
                // 'email' => 'required|email',
                'file' => 'file|mimes:pdf,doc,docx',
            ],
            ['telp_industri.regex' => 'format nomer telpon tidak valid']
        );
        if ($request->telp_industri) {
            $request->validate([
                'telp_industri' => 'regex:/^([0-9\s\-\+\(\)]*)$/',
            ]);
        }
        $file = $request->file('file');
        if ($file) {
            $nama_file = time() . "_" . $file->getClientOriginalName();
            $move = Storage::disk('surat_kerjasama')->put($nama_file, file_get_contents($file));
            if ($move) {
                $update = Kerjasama::findOrFail($request->id)->update([
                    'mitra' => $request->mitra,
                    'kerjasama' => $request->kerjasama,
                    'tanggal_mulai' => $request->tanggal_mulai,
                    'tanggal_selesai' => $request->tanggal_selesai,
                    'nomor' => $request->nomor,
                    'kegiatan' => $request->kegiatan,
                    'sifat' => $request->sifat,
                    'user_id' => Auth::user()->id,
                    'jenis_kerjasama_id' => $request->jenis_kerjasama_id,
                    'kriteria_mitra_id' => $request->kriteria_mitra_id,
                    'kriteria_kemitraan_id' => $request->kriteria_kemitraan_id,
                    'pks' => implode(',', $request->perjanjian),
                    'jurusan' => implode(',', $request->jurusan),
                    'prodi' => implode(',', $request->prodi),
                    'target_reviewer_id' => $request->target_reviewer ? implode(',', $request->target_reviewer) : null,
                    'pic_pnj' => $request->pic_pnj,
                    'alamat_perusahaan' => $request->alamat_perusahaan,
                    'pic_industri' => $request->pic_industri,
                    'jabatan_pic_industri' => $request->jabatan_pic_industri,
                    'telp_industri' => $request->telp_industri,
                    'email' => $request->email,
                    'file' => $nama_file,
                    'step' => 1,
                ]);
                if ($update) {
                    return redirect('/admin/pengajuan-kerjasama')->with('success', 'Data berhasil diubah');
                } else {
                    return redirect('/admin/pengajuan-kerjasama')->with('error', 'Data gagal diubah');
                }
            } else {
                return redirect('/admin/pengajuan-kerjasama')->with('error', 'Data gagal dipindahkan');
            }
        } else {
            $update = Kerjasama::findOrFail($request->id)->update([
                'mitra' => $request->mitra,
                'kerjasama' => $request->kerjasama,
                'tanggal_mulai' => $request->tanggal_mulai,
                'tanggal_selesai' => $request->tanggal_selesai,
                'nomor' => $request->nomor,
                'kegiatan' => $request->kegiatan,
                'sifat' => $request->sifat,
                'jenis_kerjasama_id' => $request->jenis_kerjasama_id,
                'kriteria_mitra_id' => $request->kriteria_mitra_id,
                'kriteria_kemitraan_id' => $request->kriteria_kemitraan_id,
                'pks' => implode(',', $request->perjanjian),
                'target_reviewer_id' => $request->target_reviewer ? implode(',', $request->target_reviewer) : null,
                'jurusan' => implode(',', $request->jurusan),
                'prodi' => implode(',', $request->prodi),
                'pic_pnj' => $request->pic_pnj,
                'alamat_perusahaan' => $request->alamat_perusahaan,
                'pic_industri' => $request->pic_industri,
                'jabatan_pic_industri' => $request->jabatan_pic_industri,
                'telp_industri' => $request->telp_industri,
                'email' => $request->email,
                'step' => 1,
            ]);
            if ($update) {
                return redirect('/admin/pengajuan-kerjasama')->with('success', 'Data berhasil diubah');
            } else {
                return redirect('/admin/pengajuan-kerjasama')->with('error', 'Data gagal diubah');
            }
        }

    }

    public function delete($id)
    {
        $delete = Kerjasama::findOrFail($id)->delete();
        if ($delete) {
            if (Auth::user()->role->role_name == 'pic') {
                return redirect('/pic/pengajuan-kerjasama')->with('success', 'Data berhasil dihapus');
            } else {
                return redirect('/admin/pengajuan-kerjasama')->with('success', 'Data berhasil dihapus');
            }

        } else {
            if (Auth::user()->role->role_name == 'pic') {
                return redirect('/pic/pengajuan-kerjasama')->with('error', 'Data gagal dihapus');
            } else {
                return redirect('/admin/pengajuan-kerjasama')->with('error', 'Data gagal dihapus');
            }

        }
    }
}
